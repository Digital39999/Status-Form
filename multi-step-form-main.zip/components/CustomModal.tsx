import { VStack, Flex, Button, HStack, Text, Input, Box, Image as ChakraImage, Heading, Textarea, chakra } from '@chakra-ui/react';
import { GetServerSidePropsContext } from 'next';
import { useEffect, useState } from 'react';
import Message from './Message';
import { Form } from 'formik';

export type Modal = {
	custom_id: string;
	label: string;
	style: 1 | 2; // short or long (https://media.discordapp.net/attachments/1041699450705420338/1113216623789232128/image.png)
	value?: string; // prefiled value
	placeholder?: string; // placeholder grayed in on empty
	required: boolean; // required field

	// checks
	min_length?: number;
	max_length?: number;
}

export type MessageCheck = {
	type: 'error' | 'success' | 'warn' | undefined;
	message?: string;
}

export default function CustomModal({ modal }: { modal: Modal[] | null }) {
	const [message, setMessage] = useState<MessageCheck>({
		type: undefined,
		message: undefined,
	});

    const [isSubmitting, setIsSubmitting] = useState(false);
	const [isDisabled, setIsDisabled] = useState(false);
	const [formData, setFormData] = useState(modal?.map((input) => ({
			name: input.custom_id || '',
			value: input.value || '',
		}),
	));

	useEffect(() => {
		if (!modal) setMessage({ type: 'error', message: 'There was an error fetching the form.' });
	}, [modal]);

	useEffect(() => {
		setIsDisabled(!modal || isSubmitting || modal.some((input) => {
			if (input.required && !formData?.find((data) => data.name === input.custom_id)?.value) return true;
			if (input.min_length && (formData?.find((data) => data.name === input.custom_id)?.value.length || 0) < input.min_length) return true;
			if (input.max_length && (formData?.find((data) => data.name === input.custom_id)?.value.length || 0) > input.max_length) return true;
		}));
	}, [formData, modal, isSubmitting]);

	// so, when we get data from backend, if modal is null, button = disabled, if any of modal objects (min_length, max_length) are not met, button = disabled
	// once button is being clicked, it will trigger that loading while data is being sent to backend, and then it will trigger the message, which will disable button so it cant be abused again
	// get it? leave this here

	const submit = (event: React.FormEvent<HTMLFormElement> | any) => { // heh
        event.preventDefault();
        setIsSubmitting(true);

        console.log(formData);
        
		setMessage({ type: 'success' });
        setIsSubmitting(false);
	}

    console.log(isSubmitting);

	return (
        <VStack bg='#36393f' color='white' rounded={'lg'} align={'start'} maxW={'440px'} w='100%' fontWeight={500}>
            <chakra.form onSubmit={submit} w='100%' display={'flex'} gap={2} flexDir={'column'}>
				<VStack p={4} align={'start'} w='100%'>

					<HStack pb={3} fontSize='lg'>
						<ChakraImage alt='icon' src='https://cdn.crni.xyz/r/logo.gif' width={8} height={8} rounded={'full'} />
						<Heading fontSize={'xl'} fontFamily={'body'}>
							My Cool Modal
						</Heading>
					</HStack>
					<VStack align={'start'} w='100%' spacing={3}>
						{message.type && Message(message)}

						{modal?.map((m, i) => (
							<VStack w='100%' spacing={1} align={'start'} key={i}>
								<Text fontSize={'sm'} textTransform={'uppercase'}>
									<Box as='span' opacity={.82}>{m.label}</Box>
									{m.required && <Box as='span' color='#d54144' ml={1}>*</Box>}
								</Text>

								{m.style === 1 ?
									<Input name={m.custom_id} height='3rem' placeholder={m.placeholder} variant={'filled'} bg='#202225' rounded={'md'} pl={2.5} required={m.required}
										_placeholder={{
											color: '#6e7073',
										}}
										_hover={{
											bg: '#202225',
										}}
                                        onChange={(e) => {
                                            setFormData(formData?.map((data) => {
												if (data.name === m.custom_id) return { name: m.custom_id, value: e.target.value };
												return data;
											}));
                                        }
                                    }
									/>
									:
									<Textarea name={m.custom_id} height='8rem' placeholder={m.placeholder} variant={'filled'} bg='#202225' rounded={'md'} pl={2.5} required={m.required}
										_placeholder={{
											color: '#6e7073',
										}}
										_hover={{
											bg: '#202225',
										}}
									/>
								}
							</VStack>
						))}

					</VStack>
				</VStack>

				<HStack bg='#2f3136' spacing={2} w='100%' py={3.5} px={4} justifyContent={'flex-end'} borderBottomRadius={'lg'}>
					<Button variant={'ghost'} _hover={{ bg: 'transparent', color: 'white' }}>Cancel</Button>
					<Button bg='#5865f2' rounded={'5px'} _hover={{ bg: '#5865f2' }} type='submit' isLoading={isSubmitting} disabled={isDisabled}>Submit</Button>
				</HStack>
		    </chakra.form>
		</VStack>
	);
}
