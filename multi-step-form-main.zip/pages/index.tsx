import CustomModal, { Modal } from '../components/CustomModal';
import type { NextPageContext } from 'next';
import { Flex } from '@chakra-ui/react';

const Home = ({ modal }: { modal: Modal[] | null }) => {
	return (
		<Flex w='100%' h='100vh' justifyContent={'center'} alignItems={'center'} bg='transparent' >
			<CustomModal modal={modal} />
		</Flex>
	);
};

export default Home;

async function fetchInputs(key: string): Promise<Modal[] | null> {
	const modal: Modal[] = [{
		custom_id: 'name',
		label: 'Name',
		style: 1,
		value: 'John',
		placeholder: 'John',
		required: true,

		min_length: 3,
		max_length: 32,
	}, {
		custom_id: 'bio',
		label: 'Bio',
		style: 2,
		placeholder: 'Tell us about yourself',
		required: false,

		min_length: 3,
		max_length: 256,
	}];

	return modal;
}

Home.getInitialProps = async (context: NextPageContext) => {
	const { query } = context;
	const { key } = query;
	if (!key) return { modal: null };

	const modal = await fetchInputs(key as string);
	console.log("modal", modal);
	if (!modal) return { modal: null };

	return { modal: modal };
}